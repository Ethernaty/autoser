﻿# Entity template placeholder.
